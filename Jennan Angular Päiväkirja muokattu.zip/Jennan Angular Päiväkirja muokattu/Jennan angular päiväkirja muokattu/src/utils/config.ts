export const imageConfig = {
  quality: 0.4,
  maxWidth: 800,
  maxHeight: 600,
  autoRotate: true
};
