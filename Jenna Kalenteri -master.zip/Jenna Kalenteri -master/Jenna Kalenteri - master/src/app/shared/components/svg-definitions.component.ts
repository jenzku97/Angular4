import { Component } from '@angular/core';

@Component({
  selector: 'app-svg-definitions',
  templateUrl: './svg-definitions.component.html'
})
export class SvgDefinitionsComponent {}
