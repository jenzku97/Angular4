const EntryListMockMetadata = {
  template: 'entry-list',
};

export { EntryListMockMetadata };
