import { Component } from '@angular/core';

@Component({
  selector: 'app-features-root',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class FeaturesRootComponent {}
