import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-diary',
  template: `
    <p>
      diary works!
    </p>
  `,
})
export class DiaryComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
