export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyCJcbeUFfA0FMq7nTR6uF0vGZvcle0Um3g',
    authDomain: 'diary-app-1fa1b.firebaseapp.com',
    databaseURL: 'https://diary-app-1fa1b.firebaseio.com/',
    restURL: 'https://us-central1-diary-app-1fa1b.cloudfunctions.net/app/',
    projectId: 'diary-app-1fa1b',
    storageBucket: 'gs://diary-app-1fa1b.appspot.com/',
  },
};
