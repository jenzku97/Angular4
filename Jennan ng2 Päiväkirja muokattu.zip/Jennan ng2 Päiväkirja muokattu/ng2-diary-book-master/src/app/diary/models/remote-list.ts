export interface RemoteList {
  items: object[];
}
