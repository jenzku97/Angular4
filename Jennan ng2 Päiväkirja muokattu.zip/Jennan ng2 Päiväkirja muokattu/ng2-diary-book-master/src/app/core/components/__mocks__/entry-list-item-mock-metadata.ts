const EntryListItemMockMetadata = {
  template: 'entry-list-item',
};

export { EntryListItemMockMetadata };
