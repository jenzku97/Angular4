export interface Breadcrumb {
  path: string;
}
