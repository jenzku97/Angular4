This directory contains reusable components (in general non-redux).
