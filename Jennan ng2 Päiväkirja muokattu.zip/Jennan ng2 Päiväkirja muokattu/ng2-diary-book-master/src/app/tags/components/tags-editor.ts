import { Component } from '@angular/core';

@Component({
  selector: 'app-tags-editor',
  template: `
    <md-card>
      Tags editor
    </md-card>
  `,
})
export class TagsEditorComponent {}
