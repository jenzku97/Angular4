import 'jest-preset-angular';

import './globalJestMocks';
